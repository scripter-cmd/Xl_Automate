package demo.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class App 
{
    public static void main( String[] args )
    {
    	try {
            File excelFile = new File("/home/sudhakar/Desktop/Activity_sudhakar_30.09.2024.xlsx");
            FileInputStream fis = new FileInputStream(excelFile);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            //To Check the Available sheet in the xl sheets
            
            System.out.println("Available sheets in the workbook:");
            for (int i = 0; i < wb.getNumberOfSheets(); i++) {
                System.out.println("- " + wb.getSheetName(i));
            }
            File excel =  new File ("/home/sudhakar/Desktop/Activity_sudhakar_30.09.2024.xlsx");
            
            XSSFSheet ws = wb.getSheet("Sheet1");

            int rowNum = ws.getLastRowNum() + 1;
            int colNum = ws.getRow(0).getLastCellNum();
            String [][] data = new String [rowNum] [colNum];

            for(int i = 0; i <rowNum; i++){
                XSSFRow row = ws.getRow(i);
                    for (int j = 0; j < colNum; j++){
                        XSSFCell cell = row.getCell(j);
                        String value = cell.toString();
                        data[i][j] = value;
                        System.out.print( value+" ");
                    }
                    System.out.println("");
            }
            wb.close();
            fis.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
