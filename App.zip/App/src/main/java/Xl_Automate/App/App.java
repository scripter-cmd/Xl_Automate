package Xl_Automate.App;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class App 
{
    public static void main( String[] args )
    {
    	Scanner s=new Scanner(System.in);
    	try {
            File excelFile = new File("C:\\Users\\sudhakar_d\\Desktop\\MPL_SHD_B2B Guide for API Partners_V8_BA_Comments (1).xlsx");
            FileInputStream fis = new FileInputStream(excelFile);
            XSSFWorkbook wb = new XSSFWorkbook(fis);

            XSSFSheet ws = wb.getSheet("B2B for SHD API");

            int rowNum = ws.getLastRowNum() + 1;
            int colNum = ws.getRow(0).getLastCellNum();
//            System.out.println(rowNum);
//            System.out.println(colNum);
            ArrayList<String>ar=new ArrayList<>();
            
            for(int i = 1; i <rowNum; i++){
                XSSFRow row = ws.getRow(i);
                 
                        XSSFCell cell = row.getCell(1);
                        String value = cell.toString();
                        if(!value.isEmpty())
                        {
                        	ar.add(value.replace('$', ' ')+" ");
                        }
//                        System.out.println("\n");
            }
            wb.close();
            fis.close();
            int count=4;
            String tagPath = "Session.data.account.applicant[0].address.Address1";
//            System.out.println(tagPath.replaceAll("\\[\\d+\\]", ""));
            HashMap<Integer,String> data=new HashMap<>();
            HashMap<Integer,String> value=new HashMap<>();
            for(int i=0;i<ar.size()-1;i++)
            {
//            	System.out.println(ar.get(i).trim().charAt(0)=='.'?ar.get(i).trim().substring(1):ar.get(i).trim());
//            	System.out.println(check((ar.get(i).trim().charAt(0)=='.'?"Session"+ar.get(i).trim():ar.get(i).trim()).replaceAll("\\[\\d+\\]", "")));
            	data.put(count,("Tag is present.").equals(check((ar.get(i).trim().charAt(0)=='.'?"Session"+ar.get(i).trim():ar.get(i).trim()).replaceAll("\\[\\d+\\]", "")))?"Session"+ar.get(i).trim():"Not valid");
            	value.put(count,check((ar.get(i).trim().charAt(0)=='.'?"Session"+ar.get(i).trim():ar.get(i).trim()).replaceAll("\\[\\d+\\]", "")));
            	count++;
            }
            
            System.out.println(data);
            System.out.println(value);
            String ser;
            
            do{
            	System.out.println("\nWhich Index of ROw in Your Xl Serach :\n");
            	ser=s.nextLine();
            	 if (ser.trim().equals("\\")) {
                     System.out.println("Exiting...");
                     break;
                 }
            	 else
            	 {
            		 System.out.println("Your Json Path is - >"+(data.get(Integer.parseInt(ser)))+"\nStatus -> "+value.get(Integer.parseInt(ser)));
            		 System.out.println("\n");
            	 }
            }while(true);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    	
    }
    public static String check(String tagPath)
    {
//    	System.out.println(tagPath);
    	String file = "C:\\Users\\sudhakar_d\\Desktop\\sudhakar2.txt"; // Path to your JSON file
//        String tagPath = "Session.data.account.applicant.address.Address1"; // Corrected input tag path
        
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // Read the JSON file
            JsonNode jsonNode = objectMapper.readTree(new File(file));

            // Call function to check if the tag exists
            boolean isTagPresent = checkTagExists(jsonNode, tagPath);

            // Output result
            if (isTagPresent) {
               return("Tag is present.");
            } else {
               return("Tag is not present.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
		return "";
    }
    // Function to check if the tag exists
    public static boolean checkTagExists(JsonNode jsonNode, String tagPath) {
        // Split the tagPath by periods to access each part of the path
        String[] tags = tagPath.split("\\.");

        // Navigate through the JSON structure
        for (String tag : tags) {
            if (jsonNode.has(tag)) {
                jsonNode = jsonNode.get(tag); // Move to the next level
//                System.out.println("Navigating to: " + tag + " | Value: " + jsonNode.toString()); // Print current node
            } else {
//                System.out.println("Tag not found at: " + tag);
                return false; // Tag not present
            }
        }
        return true; // Tag is present
    }
}
