package Xl_Automate.App;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestJson {
    public static void main(String[] args) {
        // Use double backslashes or a single forward slash
    	 String file = "C:\\Users\\sudhakar_d\\Desktop\\sudhakar2.txt"; // Change the path to your JSON file

         ObjectMapper objectMapper = new ObjectMapper();

         try {
             // Read JSON file and convert it into a Map
             Map<String, Object> data = objectMapper.readValue(new File(file), Map.class);

             // Access "data" section
             Map<String, Object> sessionData = (Map<String, Object>) data.get("Session");
             Map<String, Object> dataSection = getDataSection(sessionData);
             System.out.println("Agency ID: " + dataSection.get("AgencyID"));
             System.out.println("Producer Name: " + dataSection.get("ProducerName"));

             // Access "account" section
             Map<String, Object> accountSection = getAccountSection(dataSection);
             System.out.println("Ownership Type: " + accountSection.get("OwnershipType"));

             // Access "applicant" section
             Map<String, Object> applicantSection = getApplicantSection(accountSection);
             System.out.println("Applicant First Name: " + applicantSection.get("FirstName"));
             System.out.println("Applicant Last Name: " + applicantSection.get("LastName"));
             System.out.println("Applicant Date of Birth: " + applicantSection.get("DateOfBirth"));

             // Access "address" section
             Map<String, Object> addressSection = getAddressSection(applicantSection);
             System.out.println("Address Line 1: " + addressSection.get("Address1"));
             System.out.println("State: " + addressSection.get("State"));
             System.out.println("Zip Code: " + addressSection.get("ZipCode"));

             // Access "policy" section
             Map<String, Object> policySection = getPolicySection(dataSection);
             System.out.println("Policy Form: " + policySection.get("PolicyForm"));
             System.out.println("Effective Date: " + policySection.get("EffectiveDate"));

             // Access "risk" section
             List<Map<String, Object>> riskList = getRiskSection(policySection);
             for (Map<String, Object> risk : riskList) {
                 System.out.println("City/County: " + risk.get("CityCounty"));
                 System.out.println("Deductible Type: " + risk.get("DeductibleType"));

                 // Access "coverage" section within each risk
                 List<Map<String, Object>> coverageList = getCoverageSection(risk);
                 for (Map<String, Object> coverage : coverageList) {
                     System.out.println("Coverage Type: " + coverage.get("Type"));
                     System.out.println("Coverage Limit: " + coverage.get("Limit"));
                 }
             }

         } catch (IOException e) {
             e.printStackTrace();
         }
     }

     // Method to get the "data" section
     public static Map<String, Object> getDataSection(Map<String, Object> sessionData) {
         return (Map<String, Object>) sessionData.get("data");
     }

     // Method to get the "account" section
     public static Map<String, Object> getAccountSection(Map<String, Object> dataSection) {
         return (Map<String, Object>) dataSection.get("account");
     }

     // Method to get the "applicant" section
     public static Map<String, Object> getApplicantSection(Map<String, Object> accountSection) {
         return (Map<String, Object>) accountSection.get("applicant");
     }

     // Method to get the "address" section
     public static Map<String, Object> getAddressSection(Map<String, Object> applicantSection) {
         return (Map<String, Object>) applicantSection.get("address");
     }

     // Method to get the "policy" section
     public static Map<String, Object> getPolicySection(Map<String, Object> dataSection) {
         return (Map<String, Object>) dataSection.get("policy");
     }

     // Method to get the "risk" section
     public static List<Map<String, Object>> getRiskSection(Map<String, Object> policySection) {
         Map<String, Object> line = (Map<String, Object>) policySection.get("line");
         return (List<Map<String, Object>>) line.get("risk");
     }

     // Method to get the "coverage" section within "risk"
     public static List<Map<String, Object>> getCoverageSection(Map<String, Object> riskSection) {
         return (List<Map<String, Object>>) riskSection.get("coverage");
     
     }
}     


